let name="Rina";
let age=20;
let course="BSCS";

console.log("Name:name");
console.log("Age:age");
console.log("Course:course");

let numbers=["5,10,15,20"];
let colors=["Blue,Yellow,Green"];
let vehicles =["Car,Boat,Motorcycle,"];

console.log("Numbers:numbers");
console.log("Fruits:fruits");
console.log("Vehicles:vehicles");

let grade=80;

if (grade>=75){
   console.log("Passed");
}else{
    console.log("Failed") ;
}
 
if(age>=18){
    console.log("You are older.");
}else{
    console.log("You are below 18.") ;
}

let password="1475";

if(password>="1475"){
   console.log("Correct password");

}else{
    console.log("incorrect password");

}


for(let i=1; i<=5; i++){
    console.log("For loop", i);
}    

let count=1;

while(count<=5){
    console.log("While loop:",count);
}

for (let color of colors){
    console.log("Color", color);
}
















